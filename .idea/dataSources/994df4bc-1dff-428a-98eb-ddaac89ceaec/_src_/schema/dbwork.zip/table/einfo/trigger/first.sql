CREATE TRIGGER first
AFTER INSERT ON einfo
FOR EACH ROW
  begin
INSERT INTO pm (cno, data,charge)
      SELECT NEW.cno,NEW.data,etype.price*NEW.enum
        from einfo NATURAL JOIN etype;
  END;
